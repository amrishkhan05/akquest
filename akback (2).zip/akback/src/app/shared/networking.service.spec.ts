import { TestBed, inject } from '@angular/core/testing';

import { NetWorkingService } from './networking.service';

describe('NetworkingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NetWorkingService]
    });
  });

  it('should be created', inject([NetWorkingService], (service: NetWorkingService) => {
    expect(service).toBeTruthy();
  }));
});
