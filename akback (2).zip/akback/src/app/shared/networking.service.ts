import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class NetWorkingService {
    constructor(private http: Http) {}
    get(url): Observable<any> {
          return this.http.get(url).map( (response: Response) => {
                return response.json();
            }
        ).catch(this.handleError);
    }
    post(url, data): Observable<any> {
          return this.http.post(url, data).map( (response: Response) => {

            return response.json();

            }
        ).catch(this.handleError);
    }
    delete(url): Observable<any> {
        return this.http.delete(url).map( (response: Response) => {

            return response.json();
        }
    ).catch(this.handleError);
    }
    put(url, data): Observable<any> {
        return this.http.put(url, data).map( (response: Response) => {
            return response.json();
        }
    ).catch(this.handleError);
    }
    private handleError(errorResponse: Response) {

        return Observable.throw(errorResponse || 'Server error');
    }
}
