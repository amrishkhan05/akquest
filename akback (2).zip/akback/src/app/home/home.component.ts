import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { NgClass } from '@angular/common';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { NetWorkingService } from '../shared/networking.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  selectProf;
  viewCreated;
  profesionvalue;
  DoctorQuestionaires;
  EngineerQuestionaires;
  constructor(private route: ActivatedRoute, private router: Router, private networkingService: NetWorkingService) { }

  ngOnInit() {
    this.selectProf = 'makeitinvisible';
    this.viewCreated = 'makeitinvisible';
  }
  routeToForm() {
    if (this.profesionvalue === '1') {
      this.router.navigateByUrl('/doctor');
    } else if (this.profesionvalue === '2') {
      this.router.navigateByUrl('/engineer');
    }
  }
  viewQuest() {
    this.viewCreated = 'makeitvisible';
    this.selectProf = 'makeitinvisible';
    this.networkingService.get('/api/doctors').subscribe((data) => {
      this.DoctorQuestionaires = data;
    });
    this.networkingService.get('/api/engineers').subscribe((data) => {
      this.EngineerQuestionaires = data;
    });
  }
  createQuest() {
    this.selectProf = 'makeitvisible';
    this.viewCreated = 'makeitinvisible';
  }
}
