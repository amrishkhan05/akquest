const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
var cors = require('cors');
const route = require('./routes/route');
const passport = require('passport');
const mongoose = require('mongoose');
const config = require('./config/database');
const app = express();
var maxAge = 31557600000;
/*----------------DB connection ----------------*/
mongoose.Promise = global.Promise;
mongoose.connect(process.env.DATABASE);

mongoose.connection.on('connected', () => {
    console.log('connected to mongodb');
})
mongoose.connection.on('error', (err) => {
    console.log(`unable to connect to DB ${err}`);
});
/*---------------- end of DB connection ----------------*/

app.use(express.static(path.join(__dirname, 'dist'), {
    maxAge: maxAge
}));

app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());
app.use(cors());
app.use('/api', route);

const _port = process.env.PORT;

app.listen(_port, function() {
    console.log("server running on localhost:" + _port);
    //AWS.createInstance("linux");
});
//index route
app.get('/', (req, res) => {
    res.send('Invalid Endpoint !');
});