import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { NetWorkingService } from '../shared/networking.service';

@Component({
  selector: 'app-engineer',
  templateUrl: './engineer.component.html',
  styleUrls: ['./engineer.component.css']
})
export class EngineerComponent implements OnInit {

  constructor(private networkingService: NetWorkingService) { }
  public Name: string;
  public Age: Number;
  public DOB: string;
  public Gender: string;
  public AnnualIncome: string;
  ngOnInit() {
  }
  registerUser(form: NgForm) {
    console.log(form.value);
    // {email: '...', password: '...'}
    // ... <-- now use JSON.stringify() to convert form values to json.
  }
  save() {
    const newForm = {
      Name: this.Name,
      Age: this.Age,
      DOB: this.DOB,
      Gender: this.Gender,
      AnnualIncome: this.AnnualIncome
    };
    console.log('newForm');
    this.networkingService.post('/api/engineer', newForm).subscribe(data => {
      console.log(data);
    });
  }
}
